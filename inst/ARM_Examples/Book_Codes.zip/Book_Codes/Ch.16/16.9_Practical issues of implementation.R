## Defining transformed variables in R to include them as predictors in the Bugs ##
## model (see the file "16.9_Bugs_codes.bug" for the Bugs codes in this section  ##										    ##

x.sq <- x^2

