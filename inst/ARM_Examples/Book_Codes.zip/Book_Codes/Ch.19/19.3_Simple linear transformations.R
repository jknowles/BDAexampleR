z1 <- x1 - mean (x1)
z2 <- x2 - mean (x2)
